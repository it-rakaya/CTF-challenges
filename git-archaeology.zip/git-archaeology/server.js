const path = require('path');
const express = require('express');
const config = require('./config');

const app = express();
const PORT = config.port;
const publicDir = path.join(__dirname, 'public');

app.use(express.static(publicDir, { extensions: ['html'] }));

app.get('/', (req, res) => {
  res.sendFile(path.join(publicDir, 'index.html'));
});

app.get('/about', (req, res) => {
  res.sendFile(path.join(publicDir, 'about.html'));
});

app.get('/api/status', (req, res) => {
  res.json({
    service: 'crumbly-developer-portal',
    environment: config.environment,
    status: 'ok',
    uptimeSeconds: Math.round(process.uptime())
  });
});

app.listen(PORT, () => {
  console.log(`${config.appName} listening on http://localhost:${PORT}`);
});
