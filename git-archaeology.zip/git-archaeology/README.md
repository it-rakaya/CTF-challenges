# Crumbly Developer Portal

Internal developer portal for Crumbly, the bakery that supplies more than two
hundred cafés with fresh bread and pastries.

The portal is a small Express application. It exposes:

| Route             | Description                     |
| ----------------- | ------------------------------- |
| `GET /`           | Portal home page                |
| `GET /about`      | About the portal                |
| `GET /api/status` | JSON health check               |

## Getting started

Requirements: Node.js 18 or newer.

    npm install
    npm start

Then open http://localhost:3000.

## Running with Docker

    docker build -t crumbly-portal .
    docker run --rm -p 3000:3000 crumbly-portal

## Contributing

Work on a branch, keep commits small, and describe *why* in the commit message.
