// Central application configuration for the Crumbly Developer Portal.

const config = Object.freeze({
  appName: 'Crumbly Developer Portal',
  environment: process.env.NODE_ENV || 'development',
  port: Number(process.env.PORT) || 3000,
  supportEmail: 'platform@crumbly.example'
});

module.exports = config;
